# Contributing to Project

All contributions are welcome!

For contributing to this project, please:
* fork the repository to your own account
* clone the repository
* make changes
* submit a pull request with a unit test on `develop` branch
